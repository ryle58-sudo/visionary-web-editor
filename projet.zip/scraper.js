const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');

// 🔧 CONFIGURATION (à modifier selon tes besoins)
const url = 'https://example.com'; // 👈 Remplace par ton URL
const outputDir = './mon-site-importé'; // Dossier de sortie

// 🚀 FONCTION PRINCIPALE
async function scrapeSite(targetUrl, outputFolder) {
  try {
    // 1. Crée le dossier de sortie s'il n'existe pas
   
