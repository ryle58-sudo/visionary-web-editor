import React, { useState } from 'react';

function App() {
  // États pour le scraper
  const [siteUrl, setSiteUrl] = useState('');
  const [isScraping, setIsScraping] = useState(false);
  const [scrapedData, setScrapedData] = useState(null);
  const [error, setError] = useState(null);

  // Fonction pour scraper le site via le backend
  const handleScrapeSite = async () => {
    if (!siteUrl.trim()) {
      setError("Veuillez entrer une URL valide");
      return;
    }

    setIsScraping(true);
    setError(null);

    try {
      const response = await fetch('http://localhost:3000/api/scrape-site', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: siteUrl }),
      });

      if (!response.ok) throw new Error("Échec du scraping");

      const data = await response.json();
      setScrapedData(data);
      alert(`Site scrapé : ${data.title || 'Titre inconnu'}`);
    } catch (err) {
      setError(err.message);
      console.error("Erreur scraping:", err);
    } finally {
      setIsScraping(false);
    }
  };

  // Gestion de l'import de dossier local (CORRIGÉ)
  const handleFolderChange = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    // On va lire TOUS les fichiers du dossier
    const siteData = {
      files: [],
      html: null,
      css: null,
      js: null,
      title: "Mon Site Importé"
    };

    // Lire chaque fichier et stocker son contenu
    for (const file of files) {
      const fileName = file.name.toLowerCase();

      if (fileName.endsWith('.html')) {
        siteData.html = await file.text();
        siteData.title = file.name.replace('.html', '');
      }
      else if (fileName.endsWith('.css')) {
        siteData.css = await file.text();
      }
      else if (fileName.endsWith('.js')) {
        siteData.js = await file.text();
      }
      // Pour les images et autres fichiers (png, jpg, etc.)
      else if (fileName.match(/\.(jpg|jpeg|png|gif|svg|webp)$/i)) {
        siteData.files.push(URL.createObjectURL(file)); // Convertit en URL blob
      }
    }

    // Si tu as un fichier HTML, on va le prévisualiser
    if (siteData.html) {
      // On injecte le CSS et JS dans le HTML pour une meilleure prévisualisation
      const fullHtml = `
        <!DOCTYPE html>
        <html>
          <head>
            <style>${siteData.css || ''}</style>
          </head>
          <body>
            ${siteData.html}
            <script>${siteData.js || ''}</script>
          </body>
        </html>
      `;

      setScrapedData({
        ...siteData,
        preview: fullHtml,
        // On va aussi stocker les URLs des images pour les remplacer
        imageUrls: siteData.files
      });
    }

    alert(`✅ Dossier importé avec succès : ${siteData.title}`);
  };

  return (
    <div style={{ padding: '20px', maxWidth: '900px', margin: '0 auto' }}>
      <h1 style={{ textAlign: 'center', color: '#2c3e50' }}>🌐 Visionary Web Editor</h1>

      {/* SECTION IMPORT DOSSIER */}
      <div style={{
        marginBottom: '30px',
        padding: '20px',
        border: '1px solid #ddd',
        borderRadius: '8px',
        backgroundColor: '#f9f9f9'
      }}>
        <h2 style={{ color: '#3498db' }}>📁 Importer un dossier</h2>
        <input
          type="file"
          webkitdirectory="true"
          directory="true"
          multiple
          onChange={handleFolderChange}
          style={{ marginBottom: '15px', display: 'block' }}
        />
        {scrapedData?.html && (
          <div style={{ marginTop: '20px' }}>
            <h3>Prévisualisation : {scrapedData.title || "Sans titre"}</h3>
            <iframe
              srcDoc={scrapedData.preview}
              style={{
                width: '100%',
                height: '400px',
                border: '2px solid #3498db',
                borderRadius: '4px'
              }}
            />
          </div>
        )}
      </div>

      {/* SECTION SCRAPER SITE */}
      <div style={{
        padding: '20px',
        border: '1px solid #eee',
        borderRadius: '8px',
        backgroundColor: '#fff',
        boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
      }}>
        <h2 style={{ color: '#2ecc71' }}>🌍 Scraper un site web</h2>
        <input
          type="text"
          value={siteUrl}
          onChange={(e) => setSiteUrl(e.target.value)}
          placeholder="Exemple : https://example.com"
          style={{
            width: '100%',
            padding: '10px',
            marginBottom: '15px',
            border: '1px solid #ccc',
            borderRadius: '4px'
          }}
        />
        <button
          onClick={handleScrapeSite}
          disabled={isScraping}
          style={{
            padding: '12px 20px',
            backgroundColor: isScraping ? '#95a5a6' : '#2ecc71',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: isScraping ? 'not-allowed' : 'pointer',
            fontSize: '16px',
            transition: 'background 0.3s'
          }}
        >
          {isScraping ? '🔄 Scraping en cours...' : '🚀 Scraper le site'}
        </button>

        {error && (
          <p style={{
            color: '#e74c3c',
            marginTop: '15px',
            padding: '10px',
            backgroundColor: '#f8d7da',
            borderRadius: '4px'
          }}>
            ❌ {error}
          </p>
        )}
        {scrapedData?.preview && (
          <div style={{ marginTop: '25px' }}>
            <h3 style={{ color: '#34495e' }}>
              Prévisualisation : {scrapedData.title || "Titre non trouvé"}
            </h3>
            <div
              dangerouslySetInnerHTML={{ __html: scrapedData.preview }}
              style={{
                border: '1px solid #bdc3c7',
                padding: '15px',
                borderRadius: '4px',
                backgroundColor: '#ecf0f1',
                overflow: 'auto',
                maxHeight: '500px'
              }}
            />
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
