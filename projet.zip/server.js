const express = require('express');
const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 3000;

// Middleware pour parser le JSON
app.use(express.json());

// Route pour scraper un site
app.post('/api/scrape-site', async (req, res) => {
  const { url } = req.body;
  if (!url) return res.status(400).json({ error: "URL manquante" });

  try {
    const outputDir = path.join(__dirname, 'scraped-sites');
    if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir);

    const browser = await puppeteer.launch({
      headless: true,
      executablePath: 'C:\\Chromium\\chrome.exe', // ⚠️ Vérifie ce chemin !
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();
    await page.goto(url, { waitUntil: 'networkidle2', timeout: 30000 });

    const html = await page.content();
    const title = await page.title();
    await browser.close();

    // Sauvegarde les fichiers
    fs.writeFileSync(path.join(outputDir, 'index.html'), html);
    fs.writeFileSync(path.join(outputDir, 'metadata.json'), JSON.stringify({ title, url }));

    res.json({
      title,
      url,
      preview: html.substring(0, 500) + '...',
      files: ['index.html', 'metadata.json']
    });
  } catch (err) {
    console.error("Erreur Puppeteer:", err);
    res.status(500).json({ error: err.message });
  }
});

// Lance le serveur
app.listen(PORT, () => {
  console.log(`Backend Puppeteer démarré sur http://localhost:${PORT}`);
});
